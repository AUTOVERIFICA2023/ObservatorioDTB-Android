# Observatorio DTB — Generador automático del APK

Este proyecto está preparado para que GitHub genere el APK sin Android Studio.

## Pasos

1. Cree un repositorio nuevo en GitHub.
2. Suba **el contenido de la carpeta `ObservatorioDTB_Android`**, no la carpeta contenedora exterior.
   En la raíz de GitHub deben verse `app`, `.github`, `build.gradle.kts` y `settings.gradle.kts`.
3. Entre a la pestaña **Actions**.
4. Abra **Generar APK Observatorio DTB**.
5. Pulse **Run workflow** y nuevamente **Run workflow**.
6. Espere a que aparezca el visto verde.
7. Abra esa ejecución y, abajo en **Artifacts**, descargue **ObservatorioDTB-APK**.
8. Descomprima el archivo descargado. Dentro estará:
   `ObservatorioDTB.apk`
9. Suba solamente `ObservatorioDTB.apk` por FTP a:
   `/placasdtb/observatorioweb/descargas/ObservatorioDTB.apk`

El botón “Descargar App para celular” del portal quedará operativo al existir ese archivo.
